#!/bin/bash

# Create .env file if it doesn't exist
ENV_FILE=".env"
if [ ! -f "$ENV_FILE" ]; then
    touch "$ENV_FILE"
fi

# Function to prompt for input with default value
prompt_with_default() {
    local var_name=$1
    local default_value=$2
    local prompt_message=$3
    
    read -p "$prompt_message [$default_value]: " input
    echo "${input:-$default_value}"
}

# Email Configuration
MONITORING_EMAIL=$(prompt_with_default "MONITORING_EMAIL" "monitoring@${HOMELAB_DOMAIN:-your-domain.com}" "Enter monitoring email address")
ADMIN_EMAIL=$(prompt_with_default "ADMIN_EMAIL" "admin@${HOMELAB_DOMAIN:-your-domain.com}" "Enter admin email address")

# SMTP Configuration
SMTP_HOST=$(prompt_with_default "SMTP_HOST" "smtp.${HOMELAB_DOMAIN:-your-domain.com}" "Enter SMTP host")
SMTP_PORT=$(prompt_with_default "SMTP_PORT" "587" "Enter SMTP port")
SMTP_USERNAME=$(prompt_with_default "SMTP_USERNAME" "monitoring@${HOMELAB_DOMAIN:-your-domain.com}" "Enter SMTP username")
SMTP_PASSWORD=$(prompt_with_default "SMTP_PASSWORD" "" "Enter SMTP password/app-specific password")

# Slack Configuration
SLACK_WEBHOOK_URL=$(prompt_with_default "SLACK_WEBHOOK_URL" "" "Enter Slack webhook URL (optional)")
SLACK_CHANNEL=$(prompt_with_default "SLACK_CHANNEL" "#alerts" "Enter Slack channel")

# InfluxDB Configuration
INFLUXDB_USERNAME=$(prompt_with_default "INFLUXDB_USERNAME" "admin" "Enter InfluxDB username")
INFLUXDB_PASSWORD={{ vault_influxdb_admin_password }}
INFLUXDB_ORG=$(prompt_with_default "INFLUXDB_ORG" "watchtower" "Enter InfluxDB organization")
INFLUXDB_BUCKET=$(prompt_with_default "INFLUXDB_BUCKET" "watchtower" "Enter InfluxDB bucket")

# Grafana Configuration
GRAFANA_ADMIN_USER=$(prompt_with_default "GRAFANA_ADMIN_USER" "admin" "Enter Grafana admin username")
GRAFANA_ADMIN_PASSWORD={{ vault_grafana_admin_password }}
GRAFANA_DOMAIN=$(prompt_with_default "GRAFANA_DOMAIN" "grafana.local" "Enter Grafana domain")

# Backup Configuration
BACKUP_PATH=$(prompt_with_default "BACKUP_PATH" "/mnt/backup" "Enter backup path")
BACKUP_RETENTION=$(prompt_with_default "BACKUP_RETENTION" "30d" "Enter backup retention period")
BACKUP_SCHEDULE=$(prompt_with_default "BACKUP_SCHEDULE" "0 2 * * *" "Enter backup schedule (cron format)")

# Write to .env file
cat > "$ENV_FILE" << EOF
# Email Configuration
MONITORING_EMAIL=$MONITORING_EMAIL
ADMIN_EMAIL=$ADMIN_EMAIL

# SMTP Configuration
SMTP_HOST=$SMTP_HOST
SMTP_PORT=$SMTP_PORT
SMTP_USERNAME=$SMTP_USERNAME
SMTP_PASSWORD=$SMTP_PASSWORD

# Slack Configuration
SLACK_WEBHOOK_URL=$SLACK_WEBHOOK_URL
SLACK_CHANNEL=$SLACK_CHANNEL

# InfluxDB Configuration
INFLUXDB_USERNAME=$INFLUXDB_USERNAME
INFLUXDB_PASSWORD=$INFLUXDB_PASSWORD
INFLUXDB_ORG=$INFLUXDB_ORG
INFLUXDB_BUCKET=$INFLUXDB_BUCKET

# Grafana Configuration
GRAFANA_ADMIN_USER=$GRAFANA_ADMIN_USER
GRAFANA_ADMIN_PASSWORD=$GRAFANA_ADMIN_PASSWORD
GRAFANA_DOMAIN=$GRAFANA_DOMAIN

# Backup Configuration
BACKUP_PATH=$BACKUP_PATH
BACKUP_RETENTION=$BACKUP_RETENTION
BACKUP_SCHEDULE=$BACKUP_SCHEDULE
EOF

echo "Environment variables have been written to $ENV_FILE"
echo "Please review the file and make any necessary adjustments."
echo "To use these variables, source the file before running ansible-playbook:"
echo "source $ENV_FILE" 